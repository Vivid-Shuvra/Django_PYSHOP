from django.urls import path
from .views import home, login, signup, cart, checkout, orders, profile
from .middlewares.auth import auth_middleware
urlpatterns = [
    path('', home.Index.as_view(), name='homepage'),
    path('signup', signup.Signup.as_view(), name='signuppage'),
    path('login', login.Login.as_view(), name='loginpage'),
    path('logout', login.logout, name='logoutpage'),
    path('cart', cart.Cart.as_view(), name='cartpage'),
    path('checkout', auth_middleware(
        checkout.CheckOut.as_view()), name='checkout'),
    path('orders', auth_middleware(orders.OrderView.as_view()), name='orders'),
    path('profile', profile.Profile.as_view(), name='profile'),

]
