from django.shortcuts import render, redirect
from django.contrib.auth.hashers import make_password
from products.models import Customer
from django.views import View


class Signup(View):
    def get(self, request):
        return render(request, 'signup.html')

    def validateCustomer(self, customer):
        error_message = None
        if len(customer.first_name) < 3:
            error_message = '"Warning": First Name must be at least 3 characters long'
        elif len(customer.last_name) < 3:
            error_message = '"Warning": Last Name must be at least 3 characters long'
        elif len(customer.phone) < 11:
            error_message = '"Warning": Contact No must be at least 11 characters long'
        elif len(customer.email) < 5:
            error_message = '"Warning": Email must be at least 5 characters long'
        elif len(customer.password) < 6:
            error_message = '"Warning": Password must be at least 6 characters long'

        return error_message

    def post(self, request):
        postData = request.POST
        first_name = postData.get('firstname')
        last_name = postData.get('lastname')
        phone = postData.get('phone')
        email = postData.get('email')
        password = postData.get('password')

        # Validation
        value = {
            'first_name': first_name,
            'last_name': last_name,
            'phone': phone,
            'email': email
        }

        customer = Customer(first_name=first_name,
                            last_name=last_name,
                            phone=phone,
                            email=email,
                            password=password)

        error_message = self.validateCustomer(customer)
        email_error = None

        if(error_message):
            pass
        elif customer.isExists():
            email_error = '"Error": Email already registered'
        # Saving
        if not error_message and not email_error:
            customer.password = make_password(customer.password)
            customer.register()
            return redirect('homepage')
        else:
            data = {
                'error': error_message,
                'emailError': email_error,
                'values': value
            }
            return render(request, 'signup.html', data)
