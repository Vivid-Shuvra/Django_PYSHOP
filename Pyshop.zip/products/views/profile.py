from django.http import HttpResponse
from django.shortcuts import render, redirect, HttpResponseRedirect
from products.models import Customer
from django.views import View


class Profile(View):
    def get(self, request):
        customer = request.session.get('customer')
        customers = Customer.get_customer_by_id(customer)
        # return HttpResponse('Welcome!')
        return render(request, 'profile.html', {'customers': customers})
